import { Card, TextField, Button, Alert, Typography, Box } from '@mui/material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthUser } from 'src/hooks/use-auth-user';

export default function BrokerConnect() {
  const { user } = useAuthUser();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    client_id: '',
    api_key: '',
    api_secret: '',
    auth_code: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 🛑 safety checks
  if (!user) {
    return <Alert severity="error">User not found. Please login again.</Alert>;
  }

  if (user.licence !== 'Live') {
    return <Alert severity="info">Demo users cannot connect broker.</Alert>;
  }

  const handleSubmit = async () => {
    try {
      setLoading(true);
      setError('');

      const res = await fetch('http://localhost:3000/api/broker/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          broker: user.broker, 
        }),
      });

      const result = await res.json();

      if (!result.status) {
        throw new Error(result.message || 'Broker connection failed');
      }

      // ✅ UPDATE LOCAL STORAGE (THIS IS THE KEY)
      const updatedUser = {
        ...user,
        broker_connected: true,
      };

      localStorage.setItem('authUser', JSON.stringify(updatedUser));

      // 👉 redirect to dashboard
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card sx={{ p: 3, maxWidth: 600 }}>
      <Typography variant="h6">
        Connect Broker ({user.broker || 'Broker'})
      </Typography>

      <Alert severity="info" sx={{ my: 2 }}>
        Generate API credentials from your broker platform and paste details
        below. Redirect URL will be provided by admin.
      </Alert>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <TextField
        fullWidth
        label="Client ID"
        margin="normal"
        onChange={(e) => setForm({ ...form, client_id: e.target.value })}
      />

      <TextField
        fullWidth
        label="API Key"
        margin="normal"
        onChange={(e) => setForm({ ...form, api_key: e.target.value })}
      />

      <TextField
        fullWidth
        label="API Secret"
        margin="normal"
        onChange={(e) => setForm({ ...form, api_secret: e.target.value })}
      />

      <TextField
        fullWidth
        label="Auth Code"
        margin="normal"
        onChange={(e) => setForm({ ...form, auth_code: e.target.value })}
      />

      <Box mt={2}>
        <Button
          fullWidth
          variant="contained"
          disabled={loading}
          onClick={handleSubmit}
        >
          {loading ? 'Connecting...' : 'Connect Broker'}
        </Button>
      </Box>
    </Card>
  );
}
