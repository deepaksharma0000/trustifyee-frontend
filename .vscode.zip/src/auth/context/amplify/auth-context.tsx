import { createContext } from 'react';
//
import { AmplifyContextType } from '../../types';

// ----------------------------------------------------------------------

export const AuthContext = createContext({} as AmplifyContextType);
